

	<!-- Header Top ==== -->

	<header class="header rs-nav">

		<div class="sticky-header navbar-expand-lg">
            <div class="menu-bar clearfix">
                <div class="container clearfix">
					<!-- Header Logo ==== -->
					<div class="menu-logo p-1">
						<a href="index.php"><img src="assets/images/logo.png" style="float:left" class="img-fluid" alt=""></a>
					</div>
					<!-- Mobile Nav Button ==== -->
                    <button class="navbar-toggler collapsed menuicon justify-content-end" type="button" data-toggle="collapse" data-target="#menuDropdown" aria-controls="menuDropdown" aria-expanded="false" aria-label="Toggle navigation">
						<span></span>
						<span></span>
						<span></span>
					</button>
					<!-- Author Nav ==== -->
                    <div class="secondary-menu">
                        <div class="secondary-inner">
                            <!-- <ul>

								<li class="search-btn"><button id="quik-search-btn" type="button" class="btn-link"><i class="fa fa-search"></i></button></li>
							</ul> -->
						</div>
                    </div>
					<!-- Search Box ==== -->
                    <!-- <div class="nav-search-bar">
                        <form action="#">
                            <input name="search" value="" type="text" class="form-control" placeholder="Type to search">
                            <span><i class="ti-search"></i></span>
                        </form>
						<span id="search-remove"><i class="ti-close"></i></span>
                    </div> -->
					<!-- Navigation Menu ==== -->
					<div class="menu-links navbar-collapse collapse justify-content-start" style="float:right" id="menuDropdown">
						<div class="menu-logo">
							<a href="index.php"><img src="assets/images/logo.png" alt=""></a>
						</div>
						
                        <ul class="nav navbar-nav" >	
							<li><a href="index.php" >Home <!-- <i class="fa fa-chevron-down"></i> --></a>
								
							</li>
							<li><a href="about-us.php">About<!-- <i class="fa fa-chevron-down"></i> --></a>
								
							</li>

							<li><a href="javascript:;">Institutes <i class="fa fa-chevron-down"></i></a>
								<ul class="sub-menu">
									
								<li><a >Renuka foundation group of institute Kallam<i class="fa fa-angle-right"></i></a>
								<ul class="sub-menu">
									
								<li><a >Kallam Head Office<i class="fa fa-angle-right"></i></a>
								<ul class="sub-menu">
									
									<li><a href="renuka-paramedical.php">Renuka Paramedical Institute</a></li>
									<li><a href="renuka-nursing.php">Renuka Nursing <br>College</a></li>
									<li><a href="renuka-vocational.php">Renuka Vocational Training Institute</a></li>
									<li><a href="renuka-management.php">Renuka Management Institute</a></li>
									<li><a href="renuka-distance.php" >Renuka Distance Education Institute</a></li>
									<li><a href="renuka-socialwork.php">Renuka Social Work <br>Institute</a></li>

									
								</ul>
								</li>

								<li><a >Renuka foundation group of institute Ambajogai<i class="fa fa-angle-right"></i></a>
								<ul class="sub-menu">
								
									<li><a href="renuka-paramedical.php">Renuka Paramedical Institute</a></li>
									<li><a href="renuka-nursing.php">Renuka Nursing <br>College</a></li>
									<li><a href="renuka-vocational.php">Renuka Vocational Training Institute</a></li>
									<li><a href="renuka-management.php">Renuka Management Institute</a></li>
									<li><a href="renuka-distance.php" >Renuka Distance Education Institute</a></li>
									<li><a href="renuka-socialwork.php">Renuka Social Work <br>Institute</a></li>

									
								</ul>
								</li>

								<li><a >Renuka foundation group of institute Osmanabad<i class="fa fa-angle-right"></i></a>
								<ul class="sub-menu">
									
									<li><a href="renuka-paramedical.php">Renuka Paramedical Institute</a></li>
									<li><a href="renuka-nursing.php">Renuka Nursing <br>College</a></li>
									<li><a href="renuka-vocational.php">Renuka Vocational Training Institute</a></li>
									<li><a href="renuka-management.php">Renuka Management Institute</a></li>
									<li><a href="renuka-distance.php" >Renuka Distance Education Institute</a></li>
									<li><a href="renuka-socialwork.php">Renuka Social Work <br>Institute</a></li>

									
								</ul>
								</li>

								<li><a >Renuka foundation group of institute Boom<i class="fa fa-angle-right"></i></a>
								<ul class="sub-menu">
									
									<li><a href="renuka-paramedical.php">Renuka Paramedical Institute</a></li>
									<li><a href="renuka-nursing.php">Renuka Nursing <br>College</a></li>
									<li><a href="renuka-vocational.php">Renuka Vocational Training Institute</a></li>
									<li><a href="renuka-management.php">Renuka Management Institute</a></li>
									<li><a href="renuka-distance.php" >Renuka Distance Education Institute</a></li>
									<li><a href="renuka-socialwork.php">Renuka Social Work <br>Institute</a></li>

									
								</ul>
								</li>

								<li><a >Renuka foundation group of institute Barshi<i class="fa fa-angle-right"></i></a>
								<ul class="sub-menu">
									
									<li><a href="renuka-paramedical.php">Renuka Paramedical Institute</a></li>
									<li><a href="renuka-nursing.php">Renuka Nursing <br>College</a></li>
									<li><a href="renuka-vocational.php">Renuka Vocational Training Institute</a></li>
									<li><a href="renuka-management.php">Renuka Management Institute</a></li>
									<li><a href="renuka-distance.php" >Renuka Distance Education Institute</a></li>
									<li><a href="renuka-socialwork.php">Renuka Social Work <br>Institute</a></li>

									
								</ul>
								</li>

								<li><a >Renuka foundation group of institute Kolhapur<i class="fa fa-angle-right"></i></a>
								<ul class="sub-menu">
									
									<li><a href="renuka-paramedical.php">Renuka Paramedical Institute</a></li>
									<li><a href="renuka-nursing.php">Renuka Nursing <br>College</a></li>
									<li><a href="renuka-vocational.php">Renuka Vocational Training Institute</a></li>
									<li><a href="renuka-management.php">Renuka Management Institute</a></li>
									<li><a href="renuka-distance.php" >Renuka Distance Education Institute</a></li>
									<li><a href="renuka-socialwork.php">Renuka Social Work <br>Institute</a></li>

									
								</ul>
								</li>

								<li><a >Renuka foundation group of institute Parali<i class="fa fa-angle-right"></i></a>
								<ul class="sub-menu">
									
									<li><a href="renuka-paramedical.php">Renuka Paramedical Institute</a></li>
									<li><a href="renuka-nursing.php">Renuka Nursing <br>College</a></li>
									<li><a href="renuka-vocational.php">Renuka Vocational Training Institute</a></li>
									<li><a href="renuka-management.php">Renuka Management Institute</a></li>
									<li><a href="renuka-distance.php" >Renuka Distance Education Institute</a></li>
									<li><a href="renuka-socialwork.php">Renuka Social Work <br>Institute</a></li>

									
								</ul>
								</li>

								<li><a >Renuka foundation group of institute Solapur<i class="fa fa-angle-right"></i></a>
								<ul class="sub-menu">
									
									<li><a href="renuka-paramedical.php">Renuka Paramedical Institute</a></li>
									<li><a href="renuka-nursing.php">Renuka Nursing <br>College</a></li>
									<li><a href="renuka-vocational.php">Renuka Vocational Training Institute</a></li>
									<li><a href="renuka-management.php">Renuka Management Institute</a></li>
									<li><a href="renuka-distance.php" >Renuka Distance Education Institute</a></li>
									<li><a href="renuka-socialwork.php">Renuka Social Work <br>Institute</a></li>

									
								</ul>
								</li>


										
									</li>
									
								</ul>
							</li>
								

									<li><a href="admission.php">Admission Form</a></li>
								</ul>
							</li>

							
							<li><a >Management<i class="fa fa-chevron-down"></i></a>
								<ul class="sub-menu">
									<li><a href="staff.php" >Staff Members</a>
										
									</li>
									
								</ul>
							</li>

							<li class="add-mega-menu"><a>Courses<i class="fa fa-chevron-down"></i></a>
								<ul class="sub-menu add-menu">
									<li class="add-menu-left">
										<h5 class="menu-adv-title"></h5>
										<ul>
											<!-- <li><a href="courses.html">Courses </a></li> -->
											<li><a href="courses.php" >All Courses</a></li>
																					</ul>
									</li>
									<li class="add-menu-right">
										<img src="assets/images/courses/course_details2.png" alt=""/>
									</li>
								</ul>
							</li>
							<li><a href="gallery.php" >Gallery<!-- <i class="fa fa-chevron-down"></i> --></a>
								
							</li>
						
							<li><a href="contact-us.php">Contact Us</a></li>
						
						</ul>
						
                    </div>
					<!-- Navigation Menu END ==== -->
                </div>
            </div>
        </div>
    </header>


    <!-- header END ==== -->


