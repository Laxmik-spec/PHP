<style>
#width
{
    max-width:140%;

}
@media (max-width: 640px)
{
    max-width:50%;

}

</style>
<header>
        <!-- Header Start -->
        <div class="header-area">
            <div class="main-header ">
                <div class="header-bottom  header-sticky">
                    <div class="container-fluid">
                        <div class="row align-items-center">
                            <!-- Logo -->
                            <div class="col-xl-2 col-lg-2">
                                <div class="logo">
                                <a href="index.php"><img src="assets/images/logo.png" align="left" class="img-fluid float-left " alt="Responsive image"></a>
                                </div>
                            </div>
                            <div class="col-xl-10 col-lg-10">
                                <div class="menu-wrapper  d-flex align-items-center justify-content-end">
                                    <!-- Main-menu -->
                                    <div class="main-menu d-none d-lg-block">
                                        <nav>
                                            <ul id="navigation">                                                                                          
                                                <li><a href="index.php" style="font-size:22px">Home</a></li>
                                                <li><a href="about.php" style="font-size:22px">About</a></li>
                                               
                                                <li><a href="products.php" style="font-size:22px">Products</a>
                                                    <ul class="submenu">
                                                        <li><a href="wood.php">Wood Putty</a></li>
                                                        <li><a href="callibrated.php">Calibrated Filler</a></li>
                                                        <li><a href="crack.php">Crack Filler</a></li>
                                                        <li><a href="glue.php">Glue Absorber</a></li>
                                                    </ul>
                                                </li>
                                                <!-- <li><a href="gallery.php">Showcase</a></li>
                                                 <li><a href="partners.php">Partners</a></li> -->
                                                
                                                <li><a href="contact.php" style="font-size:22px">Contact</a></li>
                                            </ul>
                                        </nav>
                                    </div>
                             
                                </div>
                            </div> 
                            <!-- Mobile Menu -->
                            <div class="col-12">
                                <div class="mobile_menu d-block d-lg-none"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Header End -->
    </header>

    